import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function CartScreen({ cart, updateQuantity, remove, onConfirm }) {
  const [method, setMethod] = useState('tarjeta');
  const [cardData, setCardData] = useState({ number: '', cvv: '', date: '' });
  const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  // Manejo el proceso de pago y las validaciones
  const handlePay = () => {
    if (cart.length === 0) return;
    if (method === 'tarjeta') {
      if (cardData.number.length !== 16) {
        return Alert.alert("Error", "La tarjeta debe tener exactamente 16 números.");
      }
      if (cardData.cvv.length !== 3) {
        return Alert.alert("Error", "El CVV debe tener 3 números.");
      }
    }

    Alert.alert("¡Pago Exitoso!", "Tu stock se ha actualizado.", [
      { 
        text: "OK", 
        onPress: () => {
          onConfirm(); 
          setCardData({ number: '', cvv: '', date: '' });
        } 
      }
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Mi Pedido</Text>
      
      {/* Listado de productos en el carrito */}
      {cart.map(item => (
        <View key={item.id} style={styles.itemCard}>
          <View style={{flex: 1}}>
            <Text style={{fontWeight: 'bold'}}>{item.name} (x{item.quantity})</Text>
            <Text style={{color: '#1A56DB'}}>${(item.price * item.quantity).toFixed(2)}</Text>
          </View>

          <View style={styles.controls}>
            <TouchableOpacity onPress={() => updateQuantity(item.id, -1)} style={styles.qBtn}>
              <Text>-</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => updateQuantity(item.id, 1)} style={styles.qBtn}>
              <Text>+</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => remove(item.id)}>
              <Ionicons name="trash" size={20} color="#EF4444" />
            </TouchableOpacity>
          </View>
        </View>
      ))}

      <Text style={styles.subtitle}>Método de Pago</Text>
      
      <View style={styles.row}>
        {['tarjeta', 'transferencia', 'efectivo'].map(m => (
          <TouchableOpacity 
            key={m} 
            onPress={() => setMethod(m)} 
            style={[styles.mBtn, method === m && styles.mActive]} 
          >
            <Text style={{fontSize: 10, color: method === m ? '#FFF' : '#64748B'}}>
              {m.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Formulario*/}
      <View style={styles.form}>
        {method === 'tarjeta' ? (
          <>
            <TextInput 
              placeholder="Número de tarjeta" 
              style={styles.input} 
              keyboardType="numeric" 
              maxLength={16}
              onChangeText={(t) => setCardData({...cardData, number: t.replace(/[^0-9]/g, '')})}
              value={cardData.number}
            />
            <View style={styles.row}>
              <TextInput placeholder="MM/AA" style={[styles.input, {flex: 1, marginRight: 10}]} maxLength={5} />
              <TextInput 
                placeholder="CVV" 
                style={[styles.input, {width: 80}]} 
                keyboardType="numeric" 
                maxLength={3}
                onChangeText={(t) => setCardData({...cardData, cvv: t.replace(/[^0-9]/g, '')})}
                value={cardData.cvv}
              />
            </View>
          </>
        ) : method === 'efectivo' ? (
          <View style={styles.ticket}>
            <Text style={{textAlign: 'center'}}>TICKET GENERADO: PAGA EN CAJA</Text>
          </View>
        ) : (
          <Text style={styles.info}>Transferir a: 987654321 - Banco ShopApp</Text>
        )}
      </View>

      <Text style={styles.total}>Total: ${total.toFixed(2)}</Text>
      
      <TouchableOpacity style={styles.payBtn} onPress={handlePay}>
        <Text style={{color: '#FFF', fontWeight: 'bold'}}>CONFIRMAR Y PAGAR</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

//Estilos
const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 20, 
    backgroundColor: '#F8FAFF', 
    paddingTop: 50 
},

  title: { 
    fontSize: 26, 
    fontWeight: 'bold', 
    marginBottom: 20 
},

  itemCard: { 
    flexDirection: 'row', 
    backgroundColor: '#FFF', 
    padding: 15, 
    borderRadius: 12, 
    marginBottom: 8, 
    alignItems: 'center' 
},
  
controls: { 
    flexDirection: 'row', 
    alignItems: 'center'
},

  qBtn: { 
    backgroundColor: '#F1F5F9', 
    padding: 8, 
    borderRadius: 5, 
    marginHorizontal: 5 
},

  subtitle: { 
    fontSize: 18, 
    fontWeight: 'bold', 
    marginVertical: 15 
},

  row: { 
    flexDirection: 'row', 
    justifyContent: 'space-between' 
},

  mBtn: { 
    flex: 1, 
    padding: 10, 
    borderWidth: 1, 
    borderColor: '#DDD', 
    borderRadius: 8, 
    alignItems: 'center', 
    marginHorizontal: 2 
},

  mActive: { 
    backgroundColor: '#1A56DB', 
    borderColor: '#1A56DB' 
},

  input: { 
    backgroundColor: '#FFF', 
    padding: 12, 
    borderRadius: 8, 
    borderWidth: 1, 
    borderColor: '#DDD', 
    marginBottom: 10 
},

  form: { 
    marginTop: 10 
},

  total: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    textAlign: 'right', 
    marginVertical: 20 
},

  payBtn: { 
    backgroundColor: '#10B981', 
    padding: 18, 
    borderRadius: 12, 
    alignItems: 'center', 
    marginBottom: 40 
},

  ticket: { 
    padding: 20, 
    backgroundColor: '#FEF3C7', 
    borderRadius: 10, 
    borderStyle: 'dashed', 
    borderWidth: 1 
},

  info: { 
    padding: 15, 
    backgroundColor: '#E0F2FE', 
    borderRadius: 8, 
    color: '#0369A1'
}
});