import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, Alert } from 'react-native';

export default function ProductDetailScreen({ route, addToCart }) {
  const { product } = route.params;
  const [showModal, setShowModal] = useState(false);
  const isAvailable = product.stock > 0;

  return (
    <View style={styles.container}>
      <View style={[styles.imagePlaceholder, !isAvailable && {backgroundColor: '#E2E8F0'}]}>
        <Text style={styles.imageIcon}>{isAvailable ? '📦' : '🚫'}</Text>
      </View>
      
      <Text style={styles.name}>{product.name}</Text>
      <Text style={styles.price}>${product.price.toFixed(2)}</Text>
      
      <View style={styles.stockBadge}>
        <Text style={{color: isAvailable ? '#10B981' : '#EF4444', fontWeight: 'bold'}}>
          {isAvailable ? `Disponible: ${product.stock} unidades` : 'PRODUCTO AGOTADO'}
        </Text>
      </View>

      <Text style={styles.description}>{product.description}</Text>

      <TouchableOpacity 
        style={[styles.button, !isAvailable && {backgroundColor: '#94A3B8'}]} 
        onPress={() => isAvailable ? setShowModal(true) : Alert.alert("Lo sentimos", "No hay stock disponible")}
        disabled={!isAvailable}
      >
        <Text style={styles.buttonText}>{isAvailable ? 'Añadir al Carrito' : 'No Disponible'}</Text>
      </TouchableOpacity>

      {/* Modal de Confirmación */}
      <Modal transparent visible={showModal} animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>¿Deseas agregar este producto?</Text>
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowModal(false)}>
                <Text style={{color: '#64748B'}}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.confirmBtn} onPress={() => { addToCart(product); setShowModal(false); }}>
                <Text style={{color: '#FFF', fontWeight: 'bold'}}>Confirmar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    padding: 24, 
    backgroundColor: '#FFF' 
},
  
  imagePlaceholder: { 
    height: 200, 
    backgroundColor: '#DBEAFE', 
    borderRadius: 15, 
    justifyContent: 'center', 
    alignItems: 'center' 
},
  
  imageIcon: { 
    fontSize: 80 
},
  
  name: { 
    fontSize: 26, 
    fontWeight: 'bold', 
    marginTop: 15 
},
  
  price: { 
    fontSize: 22, 
    color: '#1A56DB', 
    fontWeight: 'bold' 
},
  
  stockBadge: { 
    marginVertical: 10, 
    padding: 5, 
    borderRadius: 5 
},
  
  description: { 
    color: '#64748B', 
    lineHeight: 22 
},
  
  button: { 
    backgroundColor: '#1A56DB', 
    padding: 18, 
    borderRadius: 12, 
    marginTop: 'auto', 
    alignItems: 'center' 
},
  
  buttonText: { 
    color: '#FFF', 
    fontWeight: 'bold' 
},
  
  modalOverlay: { 
    flex: 1, 
    backgroundColor: 'rgba(0,0,0,0.5)', 
    justifyContent: 'center', 
    padding: 20 
},
  
  modalContent: { 
    backgroundColor: '#FFF', 
    padding: 30, 
    borderRadius: 20, 
    alignItems: 'center' 
},
  
  modalTitle: { 
    fontSize: 18, 
    textAlign: 'center', 
    marginBottom: 20 
},
  
  modalActions: { 
    flexDirection: 'row' 
},
  
  confirmBtn: { 
    backgroundColor: '#1A56DB', 
    padding: 12, 
    borderRadius: 8, 
    marginLeft: 10 
},
  
  cancelBtn: { 
    padding: 12 
  }
});