import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

export default function ProductsScreen({ navigation, products }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        keyExtractor={item => item.id}
        renderItem={({ item }) => {
          const isAvailable = item.stock > 0;
          return (
            <TouchableOpacity 
              style={[styles.card, !isAvailable && styles.disabled]}
              onPress={() => isAvailable && navigation.navigate('ProductDetail', { product: item })}
            >
              <View style={{flex: 1}}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.price}>${item.price.toFixed(2)}</Text>
                <Text style={[styles.stock, {color: isAvailable ? '#10B981' : '#EF4444'}]}>
                  {isAvailable ? `Disponibles: ${item.stock}` : 'Agotado'}
                </Text>
              </View>
              <Text style={{fontSize: 20}}>{isAvailable ? '→' : '🚫'}</Text>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    backgroundColor: '#F8FAFF', 
    padding: 15 
},

  card: { 
    flexDirection: 'row', 
    backgroundColor: '#FFF', 
    padding: 20, 
    borderRadius: 15, 
    marginBottom: 10, 
    alignItems: 'center', 
    elevation: 2 
},

  disabled: { 
    opacity: 0.5, 
    backgroundColor: '#F1F5F9' 
},

  name: { 
    fontSize: 18, 
    fontWeight: 'bold' 
},

  price: { 
    fontSize: 16, 
    color: '#1A56DB' 
},

  stock: { 
    fontSize: 12, 
    fontWeight: 'bold', 
    marginTop: 5 

  }
});