import { View, Text, TouchableOpacity, TextInput, StyleSheet, Alert } from 'react-native';
import { useState, useContext } from 'react';
import { CartContext } from '../App';

export default function CheckoutScreen() {
  const [metodo, setMetodo] = useState('');
  const [tarjeta, setTarjeta] = useState('');
  const [cvv, setCvv] = useState('');

  const { cart, clearCart } = useContext(CartContext);

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const comprar = () => {
    if (metodo === 'tarjeta' && (!tarjeta || !cvv)) {
      Alert.alert('Error', 'Completa los datos de tarjeta');
      return;
    }

    clearCart();
    Alert.alert(' Compra realizada');
  };

  const soloNumeros = (text, setter) => {
    const limpio = text.replace(/[^0-9]/g, '');
    setter(limpio);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Método de Pago</Text>

      {/* BOTONES */}
      <TouchableOpacity style={styles.option} onPress={() => setMetodo('tarjeta')}>
        <Text>💳 Tarjeta</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.option} onPress={() => setMetodo('efectivo')}>
        <Text>💵 Efectivo</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.option} onPress={() => setMetodo('transferencia')}>
        <Text>📱 Transferencia</Text>
      </TouchableOpacity>

      {/* TARJETA */}
      {metodo === 'tarjeta' && (
        <View style={styles.box}>
          <TextInput
            placeholder="Número de tarjeta"
            keyboardType="numeric"
            value={tarjeta}
            onChangeText={(t) => soloNumeros(t, setTarjeta)}
            style={styles.input}
          />

          <TextInput
            placeholder="CVV"
            keyboardType="numeric"
            value={cvv}
            onChangeText={(t) => soloNumeros(t, setCvv)}
            style={styles.input}
          />
        </View>
      )}

      {/* EFECTIVO */}
      {metodo === 'efectivo' && (
        <View style={styles.box}>
          <Text style={styles.total}>Total: ${total.toFixed(2)}</Text>
          {cart.map(item => (
            <Text key={item.id}>
              {item.name} x {item.qty}
            </Text>
          ))}
        </View>
      )}

      {/* TRANSFERENCIA */}
      {metodo === 'transferencia' && (
        <View style={styles.box}>
          <Text>Banco: Banco Ejemplo</Text>
          <Text>Cuenta: 123-456-789</Text>
          <Text>Total: ${total.toFixed(2)}</Text>
        </View>
      )}

      <TouchableOpacity style={styles.btn} onPress={comprar}>
        <Text style={styles.btnText}>Confirmar Compra</Text>
      </TouchableOpacity>
    </View>
  );
}


//Estilos
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#F8FAFF' },

  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },

  option: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginTop: 10
  },

  box: {
    marginTop: 15,
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10
  },

  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginTop: 10,
    borderRadius: 8
  },

  total: { fontWeight: 'bold', marginBottom: 10 },

  btn: {
    backgroundColor: '#1A56DB',
    padding: 15,
    marginTop: 20,
    borderRadius: 10,
    alignItems: 'center'
  },

  btnText: { color: '#fff', fontWeight: 'bold' }
});