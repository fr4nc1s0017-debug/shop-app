import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';

export default function ProfileScreen({ user }) {
  const handleLogout = () => {
    Alert.alert("Cerrar Sesión", "¿Estás seguro de que quieres salir?", [
      { text: "No" },
      { text: "Sí, salir", onPress: () => console.log("Logout simulado") }
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}><Text style={{fontSize: 40}}>👤</Text></View>
        <Text style={styles.userName}>{user.name}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
        <View style={styles.badge}><Text style={styles.badgeText}>USUARIO VERIFICADO</Text></View>
      </View>

      <View style={styles.body}>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuText}>📦 Mis Pedidos Recientes</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuText}>💳 Mis Tarjetas Guardadas</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuText}>📍 Direcciones de Envío</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuText}>⚙️ Configuración</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={[styles.menuItem, {marginTop: 20}]} onPress={handleLogout}>
          <Text style={[styles.menuText, {color: '#EF4444', fontWeight: 'bold'}]}>Cerrar Sesión</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#F8FAFF' 
},

  header: { 
    backgroundColor: '#0D1B3E', 
    padding: 40, 
    alignItems: 'center', 
    borderBottomLeftRadius: 30, 
    borderBottomRightRadius: 30 
},

  avatar: { 
    width: 90, 
    height: 90, 
    borderRadius: 45, 
    backgroundColor: '#FFF', 
    justifyContent: 'center', 
    alignItems: 'center', 
    marginBottom: 10 
},

  userName: { 
    color: '#FFF', 
    fontSize: 24, 
    fontWeight: 'bold' 
},
  
  userEmail: { 
    color: '#94A3B8', 
    marginBottom: 15 
},
  
  badge: { 
    backgroundColor: '#10B981', 
    paddingHorizontal: 15, 
    paddingVertical: 5, 
    borderRadius: 20 
},
  
  badgeText: { 
    color: '#FFF', 
    fontSize: 10, 
    fontWeight: 'bold' 
},
  
  body: { 
    padding: 20 
},
  
  menuItem: { 
    backgroundColor: '#FFF', 
    padding: 18, 
    borderRadius: 12, 
    marginBottom: 10, 
    elevation: 1 
},
  
  menuText: { 
    fontSize: 16, 
    color: '#334155' 
}
});