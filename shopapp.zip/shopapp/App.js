import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';

import ProductsScreen from './screens/ProductsScreen';
import ProductDetailScreen from './screens/ProductDetailScreen';
import CartScreen from './screens/CartScreen';
import ProfileScreen from './screens/ProfileScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

export default function App() {
  const [cart, setCart] = useState([]);

  const [inventory, setInventory] = useState([
    { id: '1', name: 'Camiseta Azul', price: 15.99, stock: 12, description: 'Algodón premium.' },
    { id: '2', name: 'Zapatos Blancos', price: 45.00, stock: 0, description: 'Agotado temporalmente.' }, // Único producto sin stock
    { id: '3', name: 'Mochila Negra', price: 32.50, stock: 20, description: 'Resistente al agua.' },
  ]);

  // Agregar producto al carrito
  const addToCart = (product) => {
    setCart(prev => {
      const exists = prev.find(item => item.id === product.id);
      if (exists) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  // Eliminamos un producto específico del carrito
  const removeFromCart = (id) => setCart(prev => prev.filter(item => item.id !== id));
  
  //Actualizamos cantidad 
  const updateQuantity = (id, change) => {
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: Math.max(1, item.quantity + change) } : item
    ));
  };

  // Finalización de compra
  const completePurchase = () => {
    setInventory(prevInv => prevInv.map(prod => {
      const itemInCart = cart.find(c => c.id === prod.id);
      return itemInCart ? { ...prod, stock: prod.stock - itemInCart.quantity } : prod;
    }));
    setCart([]);
  };

  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{
        tabBarActiveTintColor: '#1A56DB',
        tabBarStyle: { backgroundColor: '#0D1B3E', height: 65, paddingBottom: 10 },
        headerShown: false
      }}>
 
        <Tab.Screen name="TiendaTab" options={{ title: 'Tienda', tabBarIcon: ({color}) => <Ionicons name="cart" size={26} color={color}/> }}>
          {() => (
            // nos permite navegar entre la lista y el detalle del producto
            <Stack.Navigator screenOptions={{ 
              headerStyle: { backgroundColor: '#0D1B3E' }, 
              headerTintColor: '#FFF' 
            }}>
              {/* Pantalla de Lista*/}
              <Stack.Screen name="Products" options={{ title: 'ShopApp' }}>
                {(props) => <ProductsScreen {...props} products={inventory} />}
              </Stack.Screen>
              
              {/* Pantalla de Detalle */}
              <Stack.Screen name="ProductDetail" options={{ title: 'Detalle' }}>
                {(props) => <ProductDetailScreen {...props} addToCart={addToCart} />}
              </Stack.Screen>
            </Stack.Navigator>
          )}
        </Tab.Screen>

        <Tab.Screen name="Carrito" options={{ tabBarIcon: ({color}) => <Ionicons name="basket" size={26} color={color}/> }}>
          {() => (
            <CartScreen 
              cart={cart} 
              updateQuantity={updateQuantity} 
              remove={removeFromCart} 
              onConfirm={completePurchase} // Se ejecuta al pagar para limpiar y descontar stock
            />
          )}
        </Tab.Screen>

        <Tab.Screen name="Perfil" options={{ tabBarIcon: ({color}) => <Ionicons name="person" size={26} color={color}/> }}>
          {() => <ProfileScreen user={{name: "Alex Dev", email: "alex.shop@correo.com"}} />}
        </Tab.Screen>

      </Tab.Navigator>
    </NavigationContainer>
  );
}